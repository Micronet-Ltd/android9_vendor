var NAVTREE_DATA =
[ [ "com.google.android.libraries.gsa.launcherclient", "reference/com/google/android/libraries/gsa/launcherclient/package-summary.html", [ [ "Annotations", null, [ [ "ThirdPartyApi", "reference/com/google/android/libraries/gsa/launcherclient/ThirdPartyApi.html", null, null, null ] ]
, null, null ], [ "Interfaces", null, [ [ "AbsServiceStatusChecker.StatusCallback", "reference/com/google/android/libraries/gsa/launcherclient/AbsServiceStatusChecker.StatusCallback.html", null, null, null ], [ "LauncherClientCallbacks", "reference/com/google/android/libraries/gsa/launcherclient/LauncherClientCallbacks.html", null, null, null ] ]
, null, null ], [ "Classes", null, [ [ "AbsServiceStatusChecker", "reference/com/google/android/libraries/gsa/launcherclient/AbsServiceStatusChecker.html", null, null, null ], [ "BuildInfo", "reference/com/google/android/libraries/gsa/launcherclient/BuildInfo.html", null, null, null ], [ "HotwordServiceChecker", "reference/com/google/android/libraries/gsa/launcherclient/HotwordServiceChecker.html", null, null, null ], [ "LauncherClient", "reference/com/google/android/libraries/gsa/launcherclient/LauncherClient.html", null, null, null ], [ "LauncherClient.ClientOptions", "reference/com/google/android/libraries/gsa/launcherclient/LauncherClient.ClientOptions.html", null, null, null ], [ "LauncherClientCallbacksAdapter", "reference/com/google/android/libraries/gsa/launcherclient/LauncherClientCallbacksAdapter.html", null, null, null ], [ "OverlayContentChecker", "reference/com/google/android/libraries/gsa/launcherclient/OverlayContentChecker.html", null, null, null ] ]
, null, null ] ]
, null, null ] ]

;


var DATA = [
      { id:0, label:"com.google.android.libraries.gsa.launcherclient", link:"reference/com/google/android/libraries/gsa/launcherclient/package-summary.html", type:"package", deprecated:"false" },
      { id:1, label:"com.google.android.libraries.gsa.launcherclient.AbsServiceStatusChecker", link:"reference/com/google/android/libraries/gsa/launcherclient/AbsServiceStatusChecker.html", type:"class", deprecated:"false" },
      { id:2, label:"com.google.android.libraries.gsa.launcherclient.AbsServiceStatusChecker.StatusCallback", link:"reference/com/google/android/libraries/gsa/launcherclient/AbsServiceStatusChecker.StatusCallback.html", type:"class", deprecated:"false" },
      { id:3, label:"com.google.android.libraries.gsa.launcherclient.BuildInfo", link:"reference/com/google/android/libraries/gsa/launcherclient/BuildInfo.html", type:"class", deprecated:"false" },
      { id:4, label:"com.google.android.libraries.gsa.launcherclient.HotwordServiceChecker", link:"reference/com/google/android/libraries/gsa/launcherclient/HotwordServiceChecker.html", type:"class", deprecated:"false" },
      { id:5, label:"com.google.android.libraries.gsa.launcherclient.LauncherClient", link:"reference/com/google/android/libraries/gsa/launcherclient/LauncherClient.html", type:"class", deprecated:"false" },
      { id:6, label:"com.google.android.libraries.gsa.launcherclient.LauncherClient.ClientOptions", link:"reference/com/google/android/libraries/gsa/launcherclient/LauncherClient.ClientOptions.html", type:"class", deprecated:"false" },
      { id:7, label:"com.google.android.libraries.gsa.launcherclient.LauncherClientCallbacks", link:"reference/com/google/android/libraries/gsa/launcherclient/LauncherClientCallbacks.html", type:"class", deprecated:"false" },
      { id:8, label:"com.google.android.libraries.gsa.launcherclient.LauncherClientCallbacksAdapter", link:"reference/com/google/android/libraries/gsa/launcherclient/LauncherClientCallbacksAdapter.html", type:"class", deprecated:"false" },
      { id:9, label:"com.google.android.libraries.gsa.launcherclient.OverlayContentChecker", link:"reference/com/google/android/libraries/gsa/launcherclient/OverlayContentChecker.html", type:"class", deprecated:"false" },
      { id:10, label:"com.google.android.libraries.gsa.launcherclient.ThirdPartyApi", link:"reference/com/google/android/libraries/gsa/launcherclient/ThirdPartyApi.html", type:"class", deprecated:"false" }

    ];
